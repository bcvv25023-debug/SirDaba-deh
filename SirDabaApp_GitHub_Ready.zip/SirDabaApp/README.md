# SirDaba Delivery - تطبيق الموزع الاحترافي

## 🏗️ هيكل المشروع

```
app/src/main/java/com/sirdaba/delivery/
├── api/
│   ├── ApiClient.java          ← Retrofit + OkHttp + JWT + Cookies
│   ├── ApiService.java         ← كل endpoints
│   ├── PersistentCookieJar.java← حفظ الكوكيز
│   └── SirDabaRepository.java  ← منطق الاتصال بالـ API
├── models/
│   └── Models.java             ← كل data models
├── services/
│   ├── SirDabaFirebaseService.java ← Push notifications (FCM)
│   └── LiveSyncService.java        ← Background polling كل 30 ثانية
├── ui/
│   ├── login/LoginActivity.java
│   ├── dashboard/DashboardActivity.java
│   ├── orders/OrdersFragment.java
│   └── notifications/NotificationsFragment.java
└── utils/
    └── TokenManager.java       ← JWT + Nonce + User session
```

## 🔌 كيف يتصل التطبيق بالموقع

### 1. تسجيل الدخول (3 خطوات تلقائية)
```
POST /wp-json/jwt-auth/v1/token        ← الحصول على JWT token
POST /wp-json/sirdaba/v1/mobile/set-app-token ← تسجيل الكوكي على الخادم
GET  /wp-json/sirdaba/v1/mobile/me     ← جلب بيانات المستخدم
```

### 2. Authentication
- **User-Agent**: `SirDaba-App-Android-Agent/2.0` (مطلوب من الخادم!)
- **Header**: `Authorization: Bearer <JWT_TOKEN>`
- **Cookies**: تُحفظ تلقائياً بـ PersistentCookieJar

### 3. AJAX Calls (WordPress)
```
POST /wp-admin/admin-ajax.php
Body: action=sirdaba_dist_accept_order&order_id=123&sd_nonce=xxx
```

### 4. Push Notifications (FCM)
```
POST /wp-json/sirdaba/v1/mobile/device-token
Body: token=FCM_TOKEN&platform=android&app_version=2.0
```

## ⚙️ الإعداد

### الخطوة 1: Firebase
1. إنشاء مشروع على [Firebase Console](https://console.firebase.google.com)
2. إضافة تطبيق Android بـ package name: `com.sirdaba.delivery`
3. تحميل `google-services.json` ووضعه في مجلد `app/`

### الخطوة 2: JWT Auth Plugin
تأكد أن الموقع يملك plugin **JWT Authentication for WP-API**
وأضف في `wp-config.php`:
```php
define('JWT_AUTH_SECRET_KEY', 'your-secret-key');
define('JWT_AUTH_CORS_ENABLE', true);
```

### الخطوة 3: Build
```bash
./gradlew assembleDebug
```
APK يخرج في: `app/build/outputs/apk/debug/`

### الخطوة 4: GitHub Actions
يوجد workflow جاهز في:
```text
.github/workflows/android-release.yml
```

- عند كل push إلى `main` أو `master` سيتم إنشاء **Debug APK** تلقائياً.
- عند التشغيل اليدوي `workflow_dispatch` يمكن إنشاء **Release APK** إذا أضفت الأسرار التالية في GitHub:
  - `ANDROID_KEYSTORE_BASE64`
  - `STORE_PASSWORD`
  - `KEY_ALIAS`
  - `KEY_PASSWORD`

لاستخدام Release signing:
1. حوّل ملف keystore إلى Base64.
2. أضفه في GitHub Secrets باسم `ANDROID_KEYSTORE_BASE64`.
3. شغّل الـ workflow يدوياً من تبويب Actions.

## ✨ الميزات

| الميزة | الوصف |
|--------|-------|
| 🔐 JWT Auth | تسجيل دخول آمن مع حفظ الجلسة |
| 🍪 Cookies | مزامنة الكوكيز مع الموقع |
| 📦 الطلبات | قبول، تسليم OTP، إلغاء |
| 🔔 Push FCM | إشعارات خارج التطبيق |
| 🔄 Live Polling | تحديث كل 30 ثانية في الخلفية |
| 📍 GPS | إرسال الموقع أثناء التوصيل |
| 💰 المحفظة | عرض الرصيد وطلبات السحب |

## 🛠️ ملاحظات مهمة

- **User-Agent** `SirDaba-App-Android-Agent` مطلوب - بدونه الخادم لا يتعرف على التطبيق
- **Nonce** يُحدَّث عند كل login - احفظه دائماً
- **LiveSyncService** يعمل كـ Foreground Service لضمان الاستمرارية في الخلفية
- عند تغيير الـ JWT، استدعِ `ApiClient.reset()` لإعادة بناء الـ client
