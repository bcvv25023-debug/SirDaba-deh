package com.sirdaba.sirdaba_delivery.api;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.*;
import okhttp3.*;

public class PersistentCookieJar implements CookieJar {

    private static final String PREFS_NAME = "sirdaba_cookies";
    private final SharedPreferences prefs;
    private final Map<String, List<Cookie>> cookieStore = new HashMap<>();

    public PersistentCookieJar(Context context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        loadFromPrefs();
    }

    @Override
    public void saveFromResponse(HttpUrl url, List<Cookie> cookies) {
        String host = url.host();
        List<Cookie> existing = cookieStore.getOrDefault(host, new ArrayList<>());

        for (Cookie newCookie : cookies) {
            existing.removeIf(c -> c.name().equals(newCookie.name()));
            existing.add(newCookie);
        }
        cookieStore.put(host, existing);
        persistToPrefs(host, existing);
    }

    @Override
    public List<Cookie> loadForRequest(HttpUrl url) {
        List<Cookie> result = new ArrayList<>();
        String host = url.host();

        // Load cookies for this host and parent domains
        for (Map.Entry<String, List<Cookie>> entry : cookieStore.entrySet()) {
            if (host.endsWith(entry.getKey()) || entry.getKey().endsWith(host)) {
                for (Cookie cookie : entry.getValue()) {
                    if (!cookie.hasExpired()) {
                        result.add(cookie);
                    }
                }
            }
        }
        return result;
    }

    public void clearAll() {
        cookieStore.clear();
        prefs.edit().clear().apply();
    }

    private void persistToPrefs(String host, List<Cookie> cookies) {
        SharedPreferences.Editor editor = prefs.edit();
        StringBuilder sb = new StringBuilder();
        for (Cookie c : cookies) {
            sb.append(c.name()).append("=").append(c.value())
              .append("|expires=").append(c.expiresAt())
              .append("|secure=").append(c.secure())
              .append(";;");
        }
        editor.putString("cookies_" + host, sb.toString());
        editor.apply();
    }

    private void loadFromPrefs() {
        Map<String, ?> all = prefs.getAll();
        // Cookies will be populated fresh on first request
        // This is simplified - production use a proper cookie serializer
    }
}
