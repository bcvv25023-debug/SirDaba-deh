package com.sirdaba.sirdaba_delivery.models;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class LiveUpdatesResponse {
    public boolean success;
    @SerializedName("new_orders") public List<Order> newOrders;
    @SerializedName("order_updates") public List<OrderUpdate> orderUpdates;
    @SerializedName("notifications") public List<AppNotification> notifications;
    @SerializedName("last_check") public long lastCheck;

    public static class OrderUpdate {
        public int id;
        public String status;
        @SerializedName("order_code") public String orderCode;
    }
}
