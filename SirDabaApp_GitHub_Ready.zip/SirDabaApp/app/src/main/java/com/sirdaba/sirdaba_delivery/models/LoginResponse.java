package com.sirdaba.sirdaba_delivery.models;

import com.google.gson.annotations.SerializedName;

public class LoginResponse {
    public boolean success;
    public String message;
    public UserPayload user;
    public String nonce;
    @SerializedName("jwt_token") public String jwtToken;

    public static class UserPayload {
        public int id;
        @SerializedName("full_name") public String fullName;
        public String email;
        public String phone;
        public String city;
        @SerializedName("user_type") public String userType;
        @SerializedName("wallet_balance") public double walletBalance;
        @SerializedName("is_approved") public int isApproved;
    }
}
