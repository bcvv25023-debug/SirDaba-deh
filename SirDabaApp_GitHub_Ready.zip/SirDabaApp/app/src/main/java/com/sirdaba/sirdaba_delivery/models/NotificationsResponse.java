package com.sirdaba.sirdaba_delivery.models;

import java.util.List;

public class NotificationsResponse {
    public boolean success;
    public NotifData data;

    public static class NotifData {
        public List<AppNotification> items;
        public int unread;
    }
}
