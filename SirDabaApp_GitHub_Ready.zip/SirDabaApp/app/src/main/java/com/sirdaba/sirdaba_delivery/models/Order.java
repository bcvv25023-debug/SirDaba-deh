package com.sirdaba.sirdaba_delivery.models;

import com.google.gson.annotations.SerializedName;

public class Order {
    public int id;
    @SerializedName("order_code") public String orderCode;
    @SerializedName("order_number") public String orderNumber;
    public String status;
    @SerializedName("client_name") public String clientName;
    @SerializedName("client_phone") public String clientPhone;
    @SerializedName("pickup_address") public String pickupAddress;
    @SerializedName("delivery_address") public String deliveryAddress;
    @SerializedName("delivery_city") public String deliveryCity;
    @SerializedName("package_value") public double packageValue;
    @SerializedName("delivery_fee") public double deliveryFee;
    @SerializedName("created_at") public String createdAt;
    @SerializedName("has_otp") public boolean hasOtp;
    public String notes;
}
