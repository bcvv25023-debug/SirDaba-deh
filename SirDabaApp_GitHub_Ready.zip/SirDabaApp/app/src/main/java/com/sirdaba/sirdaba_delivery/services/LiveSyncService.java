package com.sirdaba.sirdaba_delivery.services;

import android.app.*;
import android.content.Context;
import android.content.Intent;
import android.os.*;
import android.util.Log;
import androidx.core.app.NotificationCompat;
import com.sirdaba.sirdaba_delivery.R;
import com.sirdaba.sirdaba_delivery.api.SirDabaRepository;
import com.sirdaba.sirdaba_delivery.models.LiveUpdatesResponse;
import com.sirdaba.sirdaba_delivery.ui.dashboard.DashboardActivity;
import com.sirdaba.sirdaba_delivery.utils.TokenManager;

public class LiveSyncService extends Service {

    private static final String TAG = "LiveSyncService";
    private static final int NOTIF_ID = 1001;
    private static final long POLL_INTERVAL_MS = 30_000; // 30 seconds
    private static final String CHANNEL_SERVICE = "sirdaba_service";

    private Handler handler;
    private Runnable pollRunnable;
    private SirDabaRepository repo;
    private boolean isRunning = false;

    public static final String ACTION_START = "com.sirdaba.delivery.START_SYNC";
    public static final String ACTION_STOP  = "com.sirdaba.delivery.STOP_SYNC";
    public static final String BROADCAST_ACTION = "com.sirdaba.delivery.LIVE_UPDATE";
    public static final String EXTRA_NEW_ORDERS = "new_orders_count";
    public static final String EXTRA_NOTIFICATIONS = "notif_count";

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        repo = new SirDabaRepository(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        if (!isRunning && TokenManager.isLoggedIn(this)) {
            startForegroundNotification();
            startPolling();
            isRunning = true;
        }

        return START_STICKY;
    }

    private void startPolling() {
        pollRunnable = new Runnable() {
            @Override
            public void run() {
                if (!TokenManager.isLoggedIn(LiveSyncService.this)) {
                    stopSelf();
                    return;
                }

                repo.getLiveUpdates(new SirDabaRepository.Callback<LiveUpdatesResponse>() {
                    @Override
                    public void onSuccess(LiveUpdatesResponse data) {
                        int newOrders = data.newOrders != null ? data.newOrders.size() : 0;
                        int newNotifs = data.notifications != null ? data.notifications.size() : 0;

                        if (newOrders > 0 || newNotifs > 0) {
                            // Broadcast to UI
                            Intent broadcast = new Intent(BROADCAST_ACTION);
                            broadcast.putExtra(EXTRA_NEW_ORDERS, newOrders);
                            broadcast.putExtra(EXTRA_NOTIFICATIONS, newNotifs);
                            sendBroadcast(broadcast);

                            // Show notification if app is in background
                            if (newOrders > 0) {
                                showNewOrderNotification(newOrders);
                            }
                        }
                    }

                    @Override
                    public void onError(String message) {
                        Log.w(TAG, "Live update error: " + message);
                    }
                });

                handler.postDelayed(this, POLL_INTERVAL_MS);
            }
        };

        handler.post(pollRunnable);
    }

    private void showNewOrderNotification(int count) {
        Intent intent = new Intent(this, DashboardActivity.class);
        intent.putExtra("tab", "orders");
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

        PendingIntent pi = PendingIntent.getActivity(this, 0, intent,
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                : PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder nb = new NotificationCompat.Builder(this, SirDabaFirebaseService.CHANNEL_ORDERS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("طلبات جديدة!")
            .setContentText("لديك " + count + " طلب جديد في انتظارك")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pi);

        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(2001, nb.build());
    }

    private void startForegroundNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                CHANNEL_SERVICE, "خدمة المزامنة", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("تشغيل في الخلفية لاستقبال الطلبات");
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.createNotificationChannel(ch);
        }

        Notification notif = new NotificationCompat.Builder(this, CHANNEL_SERVICE)
            .setContentTitle("SirDaba Delivery")
            .setContentText("جاهز لاستقبال الطلبات")
            .setSmallIcon(R.drawable.ic_notification)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build();

        startForeground(NOTIF_ID, notif);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (handler != null && pollRunnable != null) {
            handler.removeCallbacks(pollRunnable);
        }
        isRunning = false;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public static void start(Context context) {
        Intent intent = new Intent(context, LiveSyncService.class);
        intent.setAction(ACTION_START);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent);
        } else {
            context.startService(intent);
        }
    }

    public static void stop(Context context) {
        Intent intent = new Intent(context, LiveSyncService.class);
        intent.setAction(ACTION_STOP);
        context.startService(intent);
    }
}
