package com.sirdaba.sirdaba_delivery.ui.orders;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.sirdaba.sirdaba_delivery.R;
import com.sirdaba.sirdaba_delivery.models.Order;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class OrdersAdapter extends RecyclerView.Adapter<OrdersAdapter.OrderViewHolder> {

    public interface OnOrderActionListener {
        void onAction(Order order, String action);
    }

    private final List<Order> orders = new ArrayList<>();
    private final OnOrderActionListener listener;

    public OrdersAdapter(List<Order> initialOrders, OnOrderActionListener listener) {
        if (initialOrders != null) {
            this.orders.addAll(initialOrders);
        }
        this.listener = listener;
    }

    public void updateOrders(List<Order> newOrders) {
        orders.clear();
        if (newOrders != null) {
            orders.addAll(newOrders);
        }
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_order, parent, false);
        return new OrderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {
        holder.bind(orders.get(position));
    }

    @Override
    public int getItemCount() {
        return orders.size();
    }

    class OrderViewHolder extends RecyclerView.ViewHolder {
        private final TextView tvOrderCode;
        private final TextView tvClientName;
        private final TextView tvAddresses;
        private final TextView tvMeta;
        private final Button btnAccept;
        private final Button btnVerifyOtp;
        private final Button btnCancel;

        OrderViewHolder(@NonNull View itemView) {
            super(itemView);
            tvOrderCode = itemView.findViewById(R.id.tv_order_code);
            tvClientName = itemView.findViewById(R.id.tv_client_name);
            tvAddresses = itemView.findViewById(R.id.tv_addresses);
            tvMeta = itemView.findViewById(R.id.tv_meta);
            btnAccept = itemView.findViewById(R.id.btn_accept);
            btnVerifyOtp = itemView.findViewById(R.id.btn_verify_otp);
            btnCancel = itemView.findViewById(R.id.btn_cancel);
        }

        void bind(Order order) {
            String code = order.orderCode != null && !order.orderCode.isEmpty() ? order.orderCode : String.valueOf(order.id);
            tvOrderCode.setText("#" + code);
            tvClientName.setText(order.clientName != null && !order.clientName.isEmpty() ? order.clientName : "عميل غير معروف");
            tvAddresses.setText(formatAddresses(order));
            tvMeta.setText(formatMeta(order));

            String status = order.status == null ? "" : order.status.toLowerCase(Locale.ROOT);
            boolean isPending = status.isEmpty() || "pending".equals(status) || "new".equals(status);
            boolean isActive = "active".equals(status) || "in_progress".equals(status) || "accepted".equals(status);

            btnAccept.setVisibility(isPending ? View.VISIBLE : View.GONE);
            btnVerifyOtp.setVisibility(isActive && order.hasOtp ? View.VISIBLE : View.GONE);
            btnCancel.setVisibility((isPending || isActive) ? View.VISIBLE : View.GONE);

            btnAccept.setOnClickListener(v -> listener.onAction(order, "accept"));
            btnVerifyOtp.setOnClickListener(v -> listener.onAction(order, "deliver_otp"));
            btnCancel.setOnClickListener(v -> listener.onAction(order, "cancel"));
        }

        private String formatAddresses(Order order) {
            String pickup = order.pickupAddress != null ? order.pickupAddress : "-";
            String delivery = order.deliveryAddress != null ? order.deliveryAddress : "-";
            return "استلام: " + pickup + "\nتسليم: " + delivery;
        }

        private String formatMeta(Order order) {
            String city = order.deliveryCity != null ? order.deliveryCity : "-";
            String fee = String.format(Locale.US, "%.2f", order.deliveryFee);
            return "المدينة: " + city + " • رسوم التوصيل: " + fee;
        }
    }
}
